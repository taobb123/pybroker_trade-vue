#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
轮动交易策略 - 虚拟环境专用版本
确保使用 tushare 作为优先数据源
"""

import os
import sys

# 修复 Python 3.12 与 Numba 兼容性问题
# 必须在导入任何使用 Numba 的库之前设置环境变量
os.environ['NUMBA_DISABLE_JIT'] = '1'

# Windows 下禁用多进程并行处理
os.environ['LOKY_MAX_CPU_COUNT'] = '1'  # 限制为单进程
os.environ['JOBLIB_TEMP_FOLDER'] = os.path.join(os.path.dirname(__file__), '.joblib_cache')

# 尝试禁用 Numba 的其他方式
try:
    import numba
    # 如果可能，禁用 Numba 的 JIT
    if hasattr(numba.config, 'DISABLE_JIT'):
        numba.config.DISABLE_JIT = True
    # 禁用错误消息高亮（避免某些错误）
    if hasattr(numba.config, 'DISABLE_ERROR_MESSAGE_HIGHLIGHTING'):
        numba.config.DISABLE_ERROR_MESSAGE_HIGHLIGHTING = True
except (ImportError, AttributeError):
    pass

# 创建一个 Numba 的 mock，如果禁用 JIT 后仍有问题
class NumbaMock:
    """Mock Numba 装饰器，当 JIT 被禁用时使用"""
    def __init__(self, *args, **kwargs):
        pass
    def __call__(self, func):
        return func

# 如果 Numba JIT 被禁用，尝试替换 njit 装饰器
if os.environ.get('NUMBA_DISABLE_JIT') == '1':
    try:
        import numba
        # 替换 njit 为普通函数
        numba.njit = lambda *args, **kwargs: lambda func: func
    except (ImportError, AttributeError):
        pass

import pybroker as pyb
from pybroker import Strategy, StrategyConfig, ExecContext
import numpy as np
import time

# 确保项目根目录在路径中
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# 强制重新加载配置，确保使用最新的数据源设置
import importlib
if 'config.settings' in sys.modules:
    importlib.reload(sys.modules['config.settings'])
if 'data.fetcher' in sys.modules:
    importlib.reload(sys.modules['data.fetcher'])

# 导入配置并强制设置 tushare 优先
from config import settings
# 确保使用 tushare 作为优先数据源
settings.DATA_CONFIG['provider_override'] = ['tushare', 'baostock', 'akshare', 'yfinance']
settings.DATA_CONFIG['api_preference'] = 'tushare'

# 强制更新 DataFetcher 中使用的 DATA_CONFIG 引用
# 因为 DataFetcher 使用 from config.settings import DATA_CONFIG
# 需要确保修改后的配置被使用
import config.settings as config_settings
config_settings.DATA_CONFIG = settings.DATA_CONFIG

# 如果 DataFetcher 已经导入，需要重新导入
if 'data.fetcher' in sys.modules:
    import data.fetcher as fetcher_module
    # 直接更新 fetcher 模块中的 DATA_CONFIG 引用
    fetcher_module.DATA_CONFIG = settings.DATA_CONFIG

print("=" * 80)
print("数据源配置信息")
print("=" * 80)
print(f"Tushare Token: {'已配置' if settings.DATA_CONFIG.get('tushare_token') else '未配置'}")
if settings.DATA_CONFIG.get('tushare_token'):
    token_preview = settings.DATA_CONFIG.get('tushare_token', '')[:10] + '...'
    print(f"Token 预览: {token_preview}")
print(f"数据源优先级: {settings.DATA_CONFIG.get('provider_override', [])}")
print("=" * 80)

# 验证 tushare 是否可用
try:
    import tushare as ts
    print("✓ tushare 模块已安装")
    # 测试 token 设置
    test_token = settings.DATA_CONFIG.get('tushare_token', '')
    if test_token:
        try:
            ts.set_token(test_token)
            print("✓ tushare token 设置成功")
        except Exception as e:
            print(f"✗ tushare token 设置失败: {e}")
    else:
        print("✗ tushare token 未配置")
except ImportError:
    print("✗ tushare 模块未安装，请运行: pip install tushare")

print("=" * 80)

# 检查 Numba 版本并给出建议
try:
    import numba
    numba_version = numba.__version__
    print(f"Numba 版本: {numba_version}")
    # Numba 0.59.0+ 支持 Python 3.12
    version_parts = [int(x) for x in numba_version.split('.')[:2]]
    if version_parts < [0, 59]:
        print("⚠️  警告: Numba 版本过低，建议升级到 0.59.0+ 以支持 Python 3.12")
        print("   升级命令: pip install --upgrade numba")
    else:
        print("✓ Numba 版本支持 Python 3.12")
except ImportError:
    print("Numba 未安装")

print("=" * 80)

from pybroker_integration.custom_data_source import create_custom_data_source

# 启用数据源缓存，提高性能
pyb.enable_data_source_cache('rotation_trade_cache_venv')

# 策略将涉及对 价格涨幅（ROC） 最高的股票进行排名和购买。首先，我们将使用 TA-Lib 定义一个 20 天的 ROC 指标：
import talib as ta

# 定义 ROC 指标，处理可能的 NaN 值
def roc_20_func(data):
    """计算 20 日 ROC 指标，处理 NaN 值"""
    roc = ta.ROC(data.close, timeperiod=20)
    # 将 NaN 和 inf 替换为 0
    roc = np.nan_to_num(roc, nan=0.0, posinf=0.0, neginf=0.0)
    return roc

roc_20 = pyb.indicator('roc_20', roc_20_func)

# 购买 20 天涨幅（ROC）最高的两只股票。
# 将我们的资本的 50% 分配给每只股票。
# 如果其中一只股票不再位于前五名的 20 天涨幅（ROC）中，则我们将清盘该股票。
# 每天交易这些规则
config = StrategyConfig(max_long_positions=2, initial_cash=50000)
pyb.param('target_size', 1 / config.max_long_positions)
pyb.param('rank_threshold', 5)


def rank(ctxs: dict[str, ExecContext]):
    """对股票按 ROC 指标进行排名"""
    scores = {}
    
    # 确保 ctxs 是字典类型
    if not isinstance(ctxs, dict):
        pyb.param('top_symbols', [])
        return
    
    # 遍历所有股票上下文
    for item in ctxs.items():
        # 确保正确解包
        if len(item) != 2:
            continue
        symbol, ctx = item
        
        try:
            roc_values = ctx.indicator('roc_20')
            if roc_values is not None and len(roc_values) > 0:
                # 获取最后一个有效值（非 NaN）
                last_value = roc_values[-1]
                if not (np.isnan(last_value) or np.isinf(last_value)):
                    scores[symbol] = float(last_value)
        except (IndexError, TypeError, ValueError, AttributeError) as e:
            # 如果指标计算失败，跳过该股票
            continue
    
    if not scores:
        # 如果没有有效的分数，设置空列表
        pyb.param('top_symbols', [])
        return
    
    # 按分数排序（降序）
    try:
        sorted_scores = sorted(
            scores.items(),
            key=lambda x: x[1] if len(x) == 2 else float('-inf'),
            reverse=True
        )
        threshold = pyb.param('rank_threshold')
        top_scores = sorted_scores[:threshold]
        # 确保正确提取 symbol
        top_symbols = []
        for item in top_scores:
            if len(item) == 2:
                top_symbols.append(item[0])
        
        pyb.param('top_symbols', top_symbols)
    except Exception as e:
        # 如果排序失败，设置空列表
        print(f"⚠ 警告: 排名排序失败: {e}")
        pyb.param('top_symbols', [])


# 我们已经有了一个根据 ROC 对股票进行排名的方法，我们可以继续实现一个 轮动 函数来管理轮动交易。
def rotate(ctx: ExecContext):
    """轮动交易函数"""
    top_symbols = pyb.param('top_symbols')
    if top_symbols is None or len(top_symbols) == 0:
        # 如果还没有排名或排名为空，不执行任何操作
        return
    
    try:
        if ctx.long_pos():
            # 如果持有股票但不在 top_symbols 中，则卖出
            if ctx.symbol not in top_symbols:
                ctx.sell_all_shares()
        else:
            # 如果股票在 top_symbols 中，则买入
            if ctx.symbol in top_symbols:
                target_size = pyb.param('target_size')
                ctx.buy_shares = ctx.calc_target_shares(target_size)
                # 获取 ROC 分数
                try:
                    roc_values = ctx.indicator('roc_20')
                    if roc_values is not None and len(roc_values) > 0:
                        ctx.score = float(roc_values[-1])
                except (IndexError, TypeError, ValueError):
                    ctx.score = 0.0
    except Exception as e:
        # 捕获任何异常，避免中断回测
        print(f"⚠ 警告: {ctx.symbol} 轮动交易异常: {e}")
        return


# 我们将使用 set_before_exec 方法在运行 轮动 函数之前使用 rank 执行我们的排名
if __name__ == '__main__':
    # 股票列表
    symbols = [
        '300750',
        '600519'
    ]
    
    print("\n" + "=" * 80)
    print("轮动交易策略回测 - 虚拟环境专用版本")
    print("=" * 80)
    print(f"股票池数量: {len(symbols)}")
    print(f"股票代码: {', '.join(symbols)}")
    print(f"回测日期范围: 2024-05-01 至 2025-12-02")
    print(f"预热期: 20 天")
    print(f"数据源: 优先使用 tushare")
    print("=" * 80)
    print("提示: 数据获取可能需要一些时间，请耐心等待...")
    print("=" * 80)
    
    try:
        # 创建数据源
        print("\n正在创建数据源...")
        data_source = create_custom_data_source()
        
        # 创建策略
        print("正在创建策略...")
        strategy = Strategy(
            data_source,
            start_date='20240501',
            end_date='20251202',
            config=config
        )
        strategy.set_before_exec(rank)
        strategy.add_execution(rotate, symbols, indicators=roc_20)
        
        # 运行回测
        start_time = time.time()
        print("\n开始回测...")
        try:
            result = strategy.backtest(warmup=20)
        except ValueError as e:
            if "too many values to unpack" in str(e):
                print(f"\n⚠️  检测到解包错误，可能是 PyBroker 内部问题")
                print(f"   错误信息: {e}")
                print(f"\n建议解决方案：")
                print(f"1. 升级 PyBroker: pip install --upgrade lib-pybroker")
                print(f"2. 检查 PyBroker 版本是否与 Python 3.12 兼容")
                print(f"3. 或者降级到 Python 3.11")
                raise
            else:
                raise
        elapsed_time = time.time() - start_time
        
        print(f"\n✓ 回测完成！耗时: {elapsed_time:.2f} 秒 ({elapsed_time/60:.2f} 分钟)")
        print("=" * 80)
        
        # 保存结果
        script_dir = os.path.dirname(os.path.abspath(__file__))
        base_filename = 'rotation_trade_result_venv.csv'
        csv_file = os.path.join(script_dir, base_filename)
        trades_df = result.trades
        
        if trades_df is not None and not trades_df.empty:
            trades_df.to_csv(csv_file, index=False, encoding='utf-8-sig')
            print(f"✓ 交易记录已保存到: {csv_file}")
            print(f"  总交易数: {len(trades_df)}")
        else:
            print("⚠ 警告: 没有交易记录")
        
        # 显示订单信息
        if hasattr(result, 'orders') and result.orders is not None:
            print(f"\n订单信息:")
            print(result.orders)
        
        # 显示指标摘要
        if hasattr(result, 'metrics_df') and result.metrics_df is not None:
            print(f"\n回测指标摘要:")
            print(result.metrics_df)
        
    except Exception as e:
        elapsed_time = time.time() - start_time if 'start_time' in locals() else 0
        print(f"\n✗ 回测过程中发生错误！耗时: {elapsed_time:.2f} 秒")
        print(f"错误类型: {type(e).__name__}")
        print(f"错误信息: {e}")
        import traceback
        print("\n详细错误堆栈:")
        traceback.print_exc()
        raise

